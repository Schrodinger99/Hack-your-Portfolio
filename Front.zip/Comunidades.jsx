import React, { useState, useEffect } from 'eact';
import axios from 'axios';

function Comunidades() {
  const [comunidades, setComunidades] = useState([]);
  const username = localStorage.getItem('username');

  useEffect(() => {
    axios.get(`http://localhost:5000/comunidades`)
     .then(response => {
        setComunidades(response.data);
      })
     .catch(error => console.error(error));
  }, []);

  const handleJoin = async (comunidadName) => {
    try {
      await axios.post(`http://localhost:5000/comunidades/unirse`, {
        community_name: comunidadName,
      });
      window.location.reload();
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <div>
      <h1>Comunidades</h1>
      <ul>
        {comunidades.map((comunidad, index) => (
          <li key={index}>
            <button onClick={() => handleJoin(comunidad.name)}>{comunidad.name}</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default Comunidades;