import React, { useState, useEffect } from 'eact';
import axios from 'axios';

function Comunidad({ match }) {
  const [mensajes, setMensajes] = useState([]);
  const [mensaje, setMensaje] = useState('');
  const comunidadName = match.params.comunidad;

  useEffect(() => {
    axios.get(`http://localhost:5000/mensajes/comunidad/${comunidadName}`)
     .then(response => {
        setMensajes(response.data.mensajes);
      })
     .catch(error => console.error(error));
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post(`http://localhost:5000/mensajes`, {
        community: comunidadName,
        content: mensaje,
      });
      setMensajes([...mensajes, response.data.mensaje]);
      setMensaje('');
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <div>
      <h1>Comunidad {comunidadName}</h1>
      <ul>
        {mensajes.map((mensaje, index) => (
          <li key={index}>{mensaje.sender}: {mensaje.content}</li>
        ))}
      </ul>
      <form onSubmit={handleSubmit}>
        <input type="text" value={mensaje} onChange={(e) => setMensaje(e.target.value)} />
        <button type="submit">Enviar</button>
      </form>
    </div>
  );
}

export default Comunidad;