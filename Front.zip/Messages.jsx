import React, { useState, useEffect } from 'eact';
import axios from 'axios';

function Mensajeria() {
  const [chatsDirectos, setChatsDirectos] = useState([]);
  const [comunidades, setComunidades] = useState([]);
  const username = localStorage.getItem('username');

  useEffect(() => {
    axios.get(`http://localhost:5000/mensajeria`)
     .then(response => {
        setChatsDirectos(response.data.chats_directos);
        setComunidades(response.data.comunidades);
      })
     .catch(error => console.error(error));
  }, []);

  return (
    <div>
      <h1>Mensajería</h1>
      <h2>Chats directos:</h2>
      <ul>
        {chatsDirectos.map((chat, index) => (
          <li key={index}>
            <a href={`/chat-directo/${chat.username}`}>{chat.username}</a>
          </li>
        ))}
      </ul>
      <h2>Comunidades:</h2>
      <ul>
        {comunidades.map((comunidad, index) => (
          <li key={index}>
            <a href={`/comunidad/${comunidad.name}`}>{comunidad.name}</a>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default Mensajeria;
