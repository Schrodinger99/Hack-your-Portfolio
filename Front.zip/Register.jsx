import React, { useState } from 'react';
import axios from 'axios';

function Registro() {
  const [username, setUsername] = useState('');
  const [correo, setCorreo] = useState('');
  const [nombre, setNombre] = useState('');
  const [edad, setEdad] = useState('');
  const [topicosInteres, setTopicosInteres] = useState([]);
  const [password, setPassword] = useState('');
  const [error, setError] = useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('http://localhost:5000/registro', {
        username,
        correo,
        nombre,
        edad,
        topicosInteres,
        password,
      });
      window.location.href = '/login';
    } catch (error) {
      setError(error.response.data.error);
    }
  };

  return (
    <div>
      <h1>Registro</h1>
      <form onSubmit={handleSubmit}>
        <label>Username:</label>
        <input type="text" value={username} onChange={(e) => setUsername(e.target.value)} />
        <br />
        <label>Correo:</label>
        <input type="email" value={correo} onChange={(e) => setCorreo(e.target.value)} />
        <br />
        <label>Nombre:</label>
        <input type="text" value={nombre} onChange={(e) => setNombre(e.target.value)} />
        <br />
        <label>Edad:</label>
        <input type="number" value={edad} onChange={(e) => setEdad(e.target.value)} />
        <br />
        <label>Tópicos de interés:</label>
        <select multiple value={topicosInteres} onChange={(e) => setTopicosInteres(e.target.value)}>
          <option value="1">Tecnología</option>
          <option value="2">Ciencia</option>
          <option value="3">Deportes</option>
          <option value="4">Deportes</option>
          <option value="5">Deportes</option>
          <option value="6">Deportes</option>
          <option value="7">Deportes</option>
          <option value="8">Deportes</option>
          <option value="9">Deportes</option>
          <option value="10">Deportes</option>
          <option value="11">Deportes</option>
          <option value="12">Deportes</option>
          <option value="13">Deportes</option>
          <option value="14">Deportes</option>
          <option value="15">Deportes</option>
        </select>
        <br />
        <label>Password:</label>
        <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
        <br />
        <button type="submit">Registro</button>
      </form>
      {error && <div style={{ color: 'ed' }}>{error}</div>}
    </div>
  );
}

export default Registro;
