import React, { useState, useEffect } from 'eact';
import axios from 'axios';

function ChatDirecto({ match }) {
  const [mensajes, setMensajes] = useState([]);
  const [mensaje, setMensaje] = useState('');
  const username = localStorage.getItem('username');
  const amigoUsername = match.params.usuario;

  useEffect(() => {
    axios.get(`http://localhost:5000/mensajes/directo/${amigoUsername}`)
     .then(response => {
        setMensajes(response.data.mensajes);
      })
     .catch(error => console.error(error));
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post(`http://localhost:5000/mensajes`, {
        sender: username,
        receiver: amigoUsername,
        content: mensaje,
      });
      setMensajes([...mensajes, response.data.mensaje]);
      setMensaje('');
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <div>
      <h1>Chat directo con {amigoUsername}</h1>
      <ul>
        {mensajes.map((mensaje, index) => (
          <li key={index}>{mensaje.sender}: {mensaje.content}</li>
        ))}
      </ul>
      <form onSubmit={handleSubmit}>
        <input type="text" value={mensaje} onChange={(e) => setMensaje(e.target.value)} />
        <button type="submit">Enviar</button>
      </form>
    </div>
  );
}

export default ChatDirecto;