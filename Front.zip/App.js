import React from 'react';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import Login from './Login';
import Registro from './Registro';
import Mensajeria from './Mensajeria';
import Comunidades from './Comunidades';
import ChatDirecto from './ChatDirecto';
import Comunidad from './Comunidad';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" exact component={Login} />
        <Route path="/registro" component={Registro} />
        <Route path="/mensajeria" component={Mensajeria} />
        <Route path="/comunidades" component={Comunidades} />
        <Route path="/chat-directo/:usuario" component={ChatDirecto} />
        <Route path="/comunidad/:comunidad" component={Comunidad} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;